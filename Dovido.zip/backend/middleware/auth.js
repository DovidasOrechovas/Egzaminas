const jwt = require('jsonwebtoken')

function auth(req, res, next) {
  try {
    //reikalingas priedas cookie parser, turi būti įrašytas į app.js
    const token = req.cookies.token;
    
    if (!token) {
      res.status(401).json({ error: "Unauthorized" });
    }

    const verified = jwt.verify(token, "superSecretPassword");

    // verified yra objektas userio, kuris prisijungęs, token decoded
    // console.log(verified);
    // pridedame vartotojo duomenis prie request'o
    req.userData=verified;
     next();
  } catch (err) {
    console.log(err);
    res.status(401).json({ error: "Unauthorized" });
  }
}

module.exports = auth;
