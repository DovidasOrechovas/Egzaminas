Start server:
1. Open command prompt
2. Go to folder backend
3. Run command npm i to install node modules
4. run kommand: npm run start
5. Wait for message: 
DB conection successful!
Server started on port 3000 and listening requests
6. Then DONE.


Users details:
{
"name": "Petras",
"email": "petras@gmail.com",
"password": "petraspetras"
}

{
"name": "Ona",
"email": "ona@gmail.com",
"password": "onaona"
}


