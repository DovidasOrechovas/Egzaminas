const Book = require("./../models/bookModel");

exports.getBooks = (req, res) => {
  const { search } = req.query;

  let searchQuery;
  try {
    if (search) {
      searchQuery = {
        title: { $regex: search, $options: "i" },
      };
    } else {
      searchQuery = req.query;
    }
    // console.log(searchQuery);

    Book.find(searchQuery)
      .populate({ path: "category", select: "title" })
      .sort({ title: 1 })
      .then((doc) => {
        res.status(200).json(doc);
      })
      .catch((err) => res.status(404).json({ error: `Bad request query` }));
  } catch {
    res.status(404).json({ error: "Get request failed, please try again" });
  }

  // ///Sort
  // try {
  //   let { sort, ...searchQuery } = req.query;
  //   Book.find(searchQuery)
  //     .sort(sort)
  //     .then((doc) => {
  //       res.status(200).json(doc);
  //     })
  //     .catch((err) => res.status(404).json({ error: `Bad request query` }));
  // } catch {
  //   res.status(404).json({ error: "Get request failed, please try again" });
  // }

  // ///Advanced filter, test:http://localhost:3000/api/books?yearmin=2010&yearmax=2013&isavail=false
  // const { yearmin, yearmax, avail } = req.query;
  // let searchObj = {};

  // if (yearmax && yearmin) {
  //   searchObj = { avail: avail, year: { $gt: yearmin, $lt: yearmax } };
  // } else {
  //   searchObj=req.body
  // }
  // try {
  //   Book.find(searchObj)
  //     .then((doc) => {
  //       res.status(200).json(doc);
  //     })
  //     .catch((err) => res.status(404).json({ error: `Bad request query` }));
  // } catch {
  //   res.status(404).json({ error: "Get request failed, please try again" });
  // }
};

exports.postNewBook = (req, res) => {
  try {
    Book.create(req.body)
      .then((doc) => {
        // console.log(doc);
        res.status(201).json(doc);
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch {
    res.status(404).json({ error: "Post request failed, please try again" });
  }
};

exports.getBookByID = (req, res, next) => {
  // console.log(req.params);
  let { id } = req.params;
  try {
    Book.findById(id)
      .populate("category")
      .then((doc) => {
        res.status(200).json(doc);
      })
      .catch((err) => res.status(404).send(err.message));
  } catch {
    res
      .status(404)
      .json({ error: "Get by ID request failed, please try again" });
  }
};

exports.deleteBook = (req, res) => {
  let { id } = req.params;
  try {
    Book.findByIdAndDelete(id)
      .then((doc) => {
        res.status(200).json(doc);
      })
      .catch((err) => res.status(404).json({ error: `Bad ID` }));
  } catch {
    res.status(404).json({ error: "Delete request failed, please try again" });
  }
};

exports.updateBook = (req, res) => {
  let { id } = req.params;
  // query option {new: true} reikalingas, kad vartotojui būtų grąžintas atnaujintas dokumentas t.y. book ir runValidators:true, kad atnaujinanat būtų validuojama pagal schemą
  try {
    Book.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    })
      .then((doc) => {
        res.status(200).json(doc);
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch {
    res.status(404).json({ error: "Update request failed, please try again" });
  }
};
