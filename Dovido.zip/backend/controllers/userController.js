const User = require("./../models/userModel");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ALL USERS
exports.getUsers = (req, res) => {
  console.log(req.query);
  try {
    User.find(req.query)
      // .sort({"title": 1})
      .then((doc) => {
        res.status(200).json(doc);
      })
      .catch((err) => res.status(404).json({ error: `Bad request query` }));
  } catch {
    res.status(404).json({ error: "Get request failed, please try again" });
  }
};

// SIGNUP
exports.signup = (req, res) => {
  const { name, email, password, role } = req.body;

  //Password hashing, need to install and require "npm i bcryptjs"
  let passwordHash;
  bcrypt.genSalt(10, function (err, salt) {
    bcrypt.hash(password, salt, function (err, hash) {
      passwordHash = hash;
    });
  });

  try {
    User.findOne({ email: email })
      .then((existingUser) => {
        if (existingUser) {
          res
            .status(422)
            .json({ error: "User exists already, please login instead." });
        } else {
          const createdUser = new User({
            name,
            email,
            password: passwordHash,
            role,
          });

          createdUser
            .save()
            .then((doc) => {
              res.status(201).json(doc);
            })
            .catch((err) => res.status(404).json({ error: err.message }));
        }
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch {
    res
      .status(500)
      .json({ error: "Signing up failed, please try again later." });
  }
};

// LOGIN
exports.login = (req, res) => {
  const { email, password } = req.body;
  // console.log(req.body);
  try {
    User.findOne({ email: email })
      .then((existingUser) => {
        // console.log(existingUser)
        //1. patikrinam, ar toks useris yra užsiregistravęs
        if (!existingUser) {
          res.status(401).json({ error: "Wrong email or password" });
        } else {
          // 2. jei yra, patikrinam ar įvestas passwordas sutampa su rastu useriu
          bcrypt.compare(password, existingUser.password).then((correct) => {
            if (!correct) {
              res.status(401).json({ error: "Wrong email or password" });
            } else {
              // 3.jei 1 ir 2 ok, generuojam token ir įrašom į naršyklės cookies
              const token = jwt.sign(
                {
                  name: existingUser.name,
                  email: existingUser.email,
                  role: existingUser.role,
                },
                "superSecretPassword"
              );
              //httpOnly provides a gate that prevents the specialized cookie from being accessed by anything other than the server
              res
              .cookie("token", token, { httpOnly: true })
              .cookie("userName", existingUser.name, { httpOnly: false })
              .send();
              // res.cookie("userName", existingUser.name, { httpOnly: flase });
            }
          });
        }
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch (err) {
    console.log(err);
  }
};

// LOGOUT
exports.logout = (req, res) => {
  res
    .cookie("token", "", {
      httpOnly: true,
      expires: new Date(0),
    })
    .cookie("userName", "", {
      httpOnly: true,
      expires: new Date(0),
    })
    .send();
};
