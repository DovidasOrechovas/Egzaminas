const Category = require("./../models/categoryModel");

exports.getCategory = (req, res) => {
  try {
    Category.find()
      .populate({ path: "books", select: ["title", "author", "year", "avail"] })
      .then((doc) => {
        // console.log(doc);
        res.status(201).json({ data: doc, user: req.userData });
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch {
    res.status(404).json({ error: "Post request failed, please try again" });
  }
};

exports.postCategory = (req, res) => {
  console.log(req.userData);
  try {
    const category = new Category({
      title: req.body.title,
      user: req.userData,
    });
    category
      .save()
      .then((doc) => {
        // console.log(doc);
        res.status(201).json(doc);
      })
      .catch((err) => res.status(404).json({ error: err.message }));
  } catch {
    res.status(404).json({ error: "Post request failed, please try again" });
  }
};
