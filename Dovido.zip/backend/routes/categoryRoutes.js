const express = require("express");
const categoryController = require("./../controllers/categoryController");
const auth = require("./../middleware/auth");

const bookRouter = express.Router();

bookRouter
  .route("/")
  .get(categoryController.getCategory)
  .post(auth, categoryController.postCategory);

module.exports = bookRouter;
