const express = require("express");
const bookController=require('./../controllers/bookController')

const bookRouter = express.Router();

bookRouter
.route("/")
.get(bookController.getBooks)
.post(bookController.postNewBook);

bookRouter
.route("/:id")
.get(bookController.getBookByID)
.patch(bookController.updateBook)
.delete(bookController.deleteBook);

module.exports=bookRouter;


