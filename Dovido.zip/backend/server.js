const app = require("./app");

//Connect To Database//
const mongoose = require("mongoose");
const mongoUri =
  "mongodb+srv://rita78:20mJ646IhRL9VH0L@cluster0.1kgwwjf.mongodb.net/myApp?retryWrites=true&w=majority";

mongoose.connect(mongoUri).then(console.log("DB conection successful!"));

// Start API Server //
const port = process.env.PORT || 3000;

app.listen(port, () => {
  console.log(`Server started on port ${port} and listening requests`);
});
