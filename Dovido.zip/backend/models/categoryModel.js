const mongoose = require("mongoose");

const categorySchema = mongoose.Schema({
  title: {
    type: String,
    required: [true, "A category must have a title"],
  },
  books: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Book",
    },
  ],
  user: { type: Object },
});

const Category = mongoose.model("Category", categorySchema);

module.exports = Category;
