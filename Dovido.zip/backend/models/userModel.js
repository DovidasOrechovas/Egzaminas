const mongoose = require("mongoose");

// user Schema//
const userSchema = mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true, minlength: 6 },
  role: {type: String, default: "user"}
});

//User Model//
const User = mongoose.model('User', userSchema);

  // User Model Export //
module.exports = User;