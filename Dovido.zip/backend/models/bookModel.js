const mongoose = require("mongoose");

// Book Schema//
const bookSchema = mongoose.Schema({
  title: {
    type: String,
    required: [true, "A book must have a title"],
  },
  author: String,
  year: Number,

  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Category",
  },
  avail: {
    type: Boolean,
    default: true,
  },
});

//Book Model//
const Book = mongoose.model("Book", bookSchema);

// Book Model Export //
module.exports = Book;
