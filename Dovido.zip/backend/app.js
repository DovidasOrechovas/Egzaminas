const express = require("express");
const bodyParser = require("body-parser");
const bookRouter = require("./routes/bookRoutes");
const userRouter = require("./routes/userRoutes");
const categoryRouter = require("./routes/categoryRoutes");
const cors = require("cors");
const auth = require("./middleware/auth");
const cookieParser = require("cookie-parser");
// swager
// const swaggerJsDoc = require("swagger-jsdoc");
// const swaggerUi = require("swagger-ui-express");


const app = express();

// swager
// const swaggerOptions = {
//   swaggerDefinition: {
//     info: {
//       version: "1.0.0",
//       title: "Budget API",
//       description: "API Information",
//       contact: { name: "Amazing Developer" },
//       servers: ["http://localhost:3000"],
//     },
//   },
// };

// const swaggerDocs = swaggerJsDoc(swaggerOptions);
// app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

// Parse incoming request bodies in a middleware before your handlers, available under the req.body property. //
app.use(bodyParser.json());

// /Only parses json and only looks at requests where the Content-Type header matches content-type: application/json.
app.use(express.json());

//paimti cookies iš request, reikia suinstaliuoti ir importuoti cookie-parser
app.use(cookieParser());

//Cors //
const corsOptions = {
  origin: "http://localhost:5173",
  optionsSuccessStatus: 200,
  // enables CORS (Cross-Origin Resource Sharing) requests with credentials
  credentials: true,
};
app.use(cors(corsOptions));

// visam route /api/categories pridedame middleware, autorizacijai, private route
// app.use("/api/categories", auth);

//Router//
app.use("/api/books", bookRouter);
app.use("/api/users", userRouter);
app.use("/api/categories", categoryRouter);

module.exports = app;
