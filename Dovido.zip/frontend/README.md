1. Go to the frontend folder
2. Open cmd
3. Run command npm i
4. Then npm run start
