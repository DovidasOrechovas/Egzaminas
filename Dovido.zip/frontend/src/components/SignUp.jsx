import axios from "axios";
import { Field, Form, Formik } from "formik";
import React from "react";
import { Button, FormControl, FormGroup, FormLabel } from "react-bootstrap";

function SignUp() {
  return (
    <div>
      <h1>Sign up form</h1>
      <Formik
        initialValues={{ name: "", email: "", password: "" }}
        onSubmit={(values) => {
          // console.log(values);
          axios
            .post("http://localhost:3000/api/users/signup", values)
            .then((response) => {
              console.log(response.data);
            })
            .catch((error) => {
              console.log(error);
            
            });
        }}
      >
        {({ handleSubmit }) => (
          <Form onSubmit={handleSubmit} style={{ maxWidth: "500px" }}>
            <FormGroup controlId="formName">
              <FormLabel>Name</FormLabel>
              <Field
                name="name"
                as={FormControl}
                type="text"
                placeholder="Enter your name"
              />
            </FormGroup>

            <FormGroup controlId="formEmail">
              <FormLabel>Email</FormLabel>
              <Field
                name="email"
                as={FormControl}
                type="email"
                placeholder="Enter your email"
              />
            </FormGroup>

            <FormGroup controlId="formPassword">
              <FormLabel>Password</FormLabel>
              <Field
                name="password"
                as={FormControl}
                type="password"
                placeholder="Enter your password"
              />
            </FormGroup>

            <Button variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default SignUp;
