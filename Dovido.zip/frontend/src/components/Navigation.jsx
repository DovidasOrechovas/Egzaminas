import { useState } from "react";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import Form from "react-bootstrap/Form";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import { LinkContainer } from "react-router-bootstrap";

function NavScrollExample({ searchBookByTitle, resetBooks }) {
  const [searchParam, setSearchParam] = useState("");

  return (
    <Navbar bg="light" expand="lg">
      <Container>
        <Navbar.Brand href="#">Books Store</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: "500px" }}
            navbarScroll
          >
            <LinkContainer to="books">
              <Nav.Link>Books</Nav.Link>
            </LinkContainer>

            <LinkContainer to="addNewBook">
              <Nav.Link>New book</Nav.Link>
            </LinkContainer>

            <LinkContainer to="addNewCategory">
              <Nav.Link>New category</Nav.Link>
            </LinkContainer>
            <LinkContainer to="signup">
              <Nav.Link>New User</Nav.Link>
            </LinkContainer>
          </Nav>
          <Form
            className="d-flex"
            onSubmit={(e) => {
              e.preventDefault();
              if (searchParam !== "") {
                searchBookByTitle(searchParam);
              } else resetBooks();
            }}
          >
            <Form.Control
              type="search"
              placeholder="Search By Title"
              className="me-2"
              aria-label="Search"
              onChange={(e) => {
                setSearchParam(e.target.value);
                if (searchParam.length < 2 || !e.target.value) {
                  resetBooks();
                }
              }}
              value={searchParam}
            />
            <Button variant="outline-success" type="submit">
              Search
            </Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavScrollExample;
