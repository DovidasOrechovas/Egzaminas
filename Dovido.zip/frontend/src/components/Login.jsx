import axios from "axios";
import { Field, Form, Formik } from "formik";
import React from "react";
import { Button, FormControl, FormGroup, FormLabel } from "react-bootstrap";

function Login() {
  return (
    <div>
      <h1>Login Form</h1>
      <Formik
        initialValues={{ email: "", password: "" }}
        onSubmit={(values, { setSubmitting }) => {
            console.log(values);
          axios
            .post("http://localhost:3000/api/users/login", values)
            .then((response) => {
              console.log(response.data);
            })
            .catch((error) => {
              console.log(error);
            });
          setSubmitting(false);
        }}
      >
        {({ errors, touched, isSubmitting }) => (
          <Form>
            <FormGroup controlId="formName">
              <FormLabel>Email</FormLabel>
              <Field
                name="email"
                as={FormControl}
                type="text"
                placeholder="Enter your email"
              />
              {errors.email && touched.email && <div>{errors.name}</div>}
            </FormGroup>

            <FormGroup controlId="formPassword">
              <FormLabel>Password</FormLabel>
              <Field
                name="password"
                as={FormControl}
                type="password"
                placeholder="Enter your password"
              />
              {errors.password && touched.password && (
                <div>{errors.password}</div>
              )}
            </FormGroup>

            <Button variant="primary" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Logging in..." : "Login"}
            </Button>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default Login;
