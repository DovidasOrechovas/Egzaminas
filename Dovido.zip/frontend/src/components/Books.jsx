import Book from "./Book";
function Books({ books }) {
  // console.log(books);
const booksjsx = books.map((book) => <Book key={book._id} book={book} />);
  return (
    <div>
      <div>
      </div>
      <h1>Paslaugos</h1>
     <div className="books-list d-flex flex-wrap">{booksjsx}</div>
    </div>
  );
}

export default Books;
