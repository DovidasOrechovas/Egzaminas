function AddCategory() {
    return ( 
        <div>
            <h1>Add new Category</h1>
        </div>
     );
}

export default AddCategory;