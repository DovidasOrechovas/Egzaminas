function AddBook() {
    return ( 
        <div>
            <h1>Add new Book</h1>
        </div>
     );
}

export default AddBook;