import Card from "react-bootstrap/Card";

function Book({ book }) {
  return (
    <Card border="secondary" style={{ width: "18rem" }} className="m-2">
      <Card.Header>Paslauga: {book.paslauga}</Card.Header>
      <Card.Body>
        <Card.Title>{book & book.paslauga}</Card.Title>
        <Card.Text>Kaina: {book.kaina}</Card.Text>
        {book.category && (
          <Card.Text>Category: {book.category.title}</Card.Text>
        )}
        <Card.Text>Available: {book.avail.toString()}</Card.Text>
        <Card.Text>Telefono numeris: {book.numeris.toString()}</Card.Text>
      </Card.Body>
    </Card>
  );
}

export default Book;
