import axios from "axios";
import { useEffect, useState } from "react";
import { Route, Routes } from "react-router-dom";

import AddBook from "./components/AddBook";
import AddCategory from "./components/AddCategory";
import Books from "./components/Books";
import Login from "./components/Login";
import Navigation from "./components/Navigation";
import SignUp from "./components/SignUp";
import { getBooks, searchBooks } from "./services/api";

//  useful hen React application needs to communicate with a server on a different domain, and that server requires authentication
axios.defaults.withCredentials = true;

function App() {
  const [books, setBooks] = useState([]);
  const [reset, setReset] = useState(false);

  useEffect(() => {
    getBooks().then((data) => {
      setBooks(data);
    });
  }, [reset]);

  function searchBookByTitle(title) {
    searchBooks(title).then((res) => setBooks(res));
  }

  function resetBooks() {
    setReset((reset) => !reset);
  }

  return (
    <div className="App">
      <Navigation
        searchBookByTitle={searchBookByTitle}
        resetBooks={resetBooks}
      />
      <Routes>
        <Route path="/" element={<Books books={books} />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/books" element={<Books books={books} />} />
        <Route path="/addNewBook" element={<AddBook />} />
        <Route path="/addNewCategory" element={<AddCategory />} />
      </Routes>
    </div>
  );
}

export default App;
