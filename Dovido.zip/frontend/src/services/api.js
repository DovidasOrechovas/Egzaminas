import axios from "axios";

const baseURL = "http://localhost:3000/api/books";

export const getBooks = ()=>{
    return (
    axios.get(baseURL)
    .then(res=>res.data)
    .catch(err=>err.message)
    )
}

export const searchBooks = (title)=>{
    return (
    axios.get(baseURL+"?search="+title)
    .then(res=>res.data)
    .catch(err=>err.message)
    )
}